"""CircAdapt Error functions."""

def catch_general_error(func):
    """
    Raise error on non existance.

    If parameter does not exist, raise error.

    Returns
    -------
        True (boolean) on success

    Raises
    ------
        NameError if not success
    """

    def inner(self, par, *arg, **kwarg):
        try:
            return func(self, par, *arg, **kwarg)
        except OSError:
            raise OSError('Unknown error while communicating with parameter ',
                          par)
    return inner


def raise_error_on_non_existance_set(func):
    """
    Raise error on non existance.

    If parameter does not exist, raise error.

    Returns
    -------
        True (boolean) on success

    Raises
    ------
        NameError if not success
    """

    def inner(self, par, *arg, **kwarg):
        is_success = func(self, par, *arg, **kwarg)
        if is_success:
            return True
        raise NameError('Parameter "'+par+'" could not be found.')
    return inner


def except_OSerror(func):
    """Catch OSError and give a userfriendly exception."""

    def inner(self, *arg, **kwarg):
        try:
            return func(self, *arg, **kwarg)
        except OSError as e:
            raise Exception(
                'Something went wrong in the model. Please minimize the code '
                'to reproduce this error and report this issue on the GIT.'
                ) from e
    return inner


class CircAdaptException(Exception):
    """General CircAdapt error."""


class ModelNotStable(CircAdaptException):
    """Model is not stable, consecutive beats are not the same."""

    def __init__(self):
        self.msg = 'Model is not stable.'

    def __str__(self):
        """Return self.msg."""
        return self.msg


class ModelCrashed(CircAdaptException):
    """Model is crashed, nans are present in the signal."""

    def __init__(self):
        self.msg = 'Model is numerically crashed.'

    def __str__(self):
        """Return self.msg."""
        return self.msg


class TriggerNotFound(CircAdaptException):
    """Trigger is not found."""

    def __init__(self, par):
        self.msg = 'Trigger for "'+par+'" is not found.'

    def __str__(self):
        """Return self.msg."""
        return self.msg


class CorruptBuild(CircAdaptException):
    """Model is not properly built."""

    def __init__(self):
        self.msg = 'Model is not properly built.\n Make sure all components '\
            'in the model are connected before you run the model, or before '\
            'you get or set parameters.'

    def __str__(self):
        """Return self.msg."""
        return self.msg
