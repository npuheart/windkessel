"""Patch objects."""
from circadapt.components import Component
from circadapt.components.wall import Wall, Wall2022, LoadExperiment
import numpy as np

class Patch(Component):
    """
    The Patch describes the relationship between
    :math:`{\\sigma}_f = {\\varepsilon}_f`.

    Parameters
    ==========
    Am_ref [:math:`m^2`]: float
        Reference wall area at :math:`l_{s} = l_{s,ref}`.
    V_wall [:math:`m^3`]: float
        Wall volume
    v_max [:math:`\\mu m/s`]: float
        Maximum shortening velocity
    l_se0 [:math:`\\mu m`]: float
        lgth of the series elastic element, i.e. :math:`l_{s} -l_{si}` for
        which stress is zero.
    l_s0 [:math:`\\mu m`]: float
        Reference sarcomere lgth for which at
        :math:`A_m (l_{s,ref}) = A_{m,ref}`.
    dl_s_pas [:math:`\\mu m`]: float
        Nonlinear exponent of Titin stress
    Sf_pas [Pa]: float
        Linear ECM stress coefficient
    fac_Sf_tit [-]: float
        Contribution factor of titen stress multiplied with Sf_act
    k1 [-]: float
        Nonlinear exponent ECM stress component
    tr [s]: float
        Contraction time constant
    td [s]: float
        Relaxation time constant
    time_act [-]: float
        Relative contraction duration
    Sf_act [Pa]: float
        Linear active stress component
    dt [s]: float
        Activation delay relative to intrinsic activation
    C_rest [-]: float
        Rest contractility
    l_si0 [:math:`\\mu m`]: float
        Reference lgth for zero-active-stress
    LDAD [s]: float
        strain dependend activation duration
    ADO [s]: float
        activation duration offset
    LDCC [-]: float
        stretch dependend contractility coefficient
    Sf_pasMaxT: float
        Maximum ecm stress (adaptation sens variable)
    Sf_pasActT: float
        Active weighted passive stress (adaptation sens variable)
    FacSf_actT: float
        Active stress (adaptation sens variable)
    LsPasActT: float
        Weighted sarcomere lgth average (adaptation sens variable)
    adapt_gamma: bool
        Adaptation constant

    Signals
    =======
    Signals are arrays. Each point in the array represents a point in time with
    step-size controlled by the solver.

    l_s [:math:`\\mu m`]: array
        Sarcomere lgth
    l_si [:math:`\\mu m`]: array
        State variable: Intrinsic sarcomere lgth
    LsiDot [:math:`\\mu m/s`]: array
        State variable: Intrinsic sarcomere lgth time-derivative
    C [-]: array
        State variable: contraction curve
    C_dot [1/s]: array
        State variable: contraction time-derivative
    Am [m:sup:`2`]: array
        Patch mid-wall area
    Am0 [m:sup:`2`]: array
        Patch mid-wall zero-stress area
    Ef [-]: array
        Natural strain
    dA_dT [m / N]: array
        Area-tension derivative
    Sf [Pa]: array
        Total fibre stress at mid-wall
    Sf_pasT [Pa]: array
        Total passive stress at mid-wall
    SfEcm [Pa]: array
        Total ECM stress at mid-wall
    dSf_dEf [Pa]: array
        Total stiffness coefficient
    dSf_pas_dEf [Pa]: array
        Total passive stiffness coefficient
    SfEcmMax: array
        Adaptation: Maximum ECM stress
    Sf_actMax: array
        Adaptation: maximum active stress
    Sf_pasAct: array
        Adaptation: active-weighted passive stress
    LsPasAct: array
        Adaptation: active-weigthed sarcomere lgth

    """

    parameters = [
        'Am_ref',
        'V_wall',
        'v_max',
        'l_se0',
        'l_s0',
        'l_s_ref',
        'dl_s_pas',
        'Sf_pas',
        'ft1_const',
        'tr',
        'td',
        'time_act',
        'Sf_act',
        'fac_Sf_tit',
        'k1',
        'dt',
        'C_rest',
        'l_si0',
        'LDAD',
        'ADO',
        'LDCC',
        'SfPasMaxT',
        'SfPasActT',
        'FacSfActT',
        'LsPasActT',
        'adapt_gamma',
        'transmat00',
        'transmat01',
        'transmat02',
        'transmat03',
        'transmat10',
        'transmat11',
        'transmat12',
        'transmat13',
        'transmat20',
        'transmat21',
        'transmat22',
        'transmat23',
        ]

    signals = [
        'l_s',
        'l_si',
        'l_si_dot',
        'C',
        'C_dot',
        'Cm',
        'Am',
        'Am0',
        'Ef',
        'dA_dT',
        'Sf',
        'Sf_pas_total',
        'Sf_ecm',
        'dSf_dEf',
        'dSf_pas_dEf',
        'SfEcmMax',
        'SfActMax',
        'SfPasAct',
        'LsPasAct',
        'moment_of_activation',
        ]

    def __init__(self, model, objects=None, wall_locs=None):
        """
        Patch2022 is based on Patch in Walmsley 2015.

        Number of patches and their names may vary and are automatically
        detected from the model object.

        Parameters
        ----------
        model: circadapt.Circadapt
            Model object.
        objects: list, optional
            List of objects in c++ this object refers to. If not given,
            the list is build based on wall_locs.
        wall_locs: list, optional
            List of wall locations in c++. This list is used to generate the
            objects.

        """
        self._model = model
        self._wall_locs = wall_locs
        if objects is None:
            objects = self.get_all_patches()
        super().__init__(model, objects)

    def build(self):
        """
        (re)build patch locations based on wall locations.

        There is no compatibility with different types of patches used in the
        model. If you use different type of patches, please use the direct way
        of interacting with the c++ object, i.e. set() and get().
        """
        self.objects = self.get_all_patches()
        super().build()

    def get_all_patches(self):
        """Get all patches of the walls included in this pointer object."""

        # get all wall objects from all possible walls
        if self._wall_locs is None:
            _wall_locs = []
            for component in self._model._components.values():
                if isinstance(component, (Wall, LoadExperiment)):
                    _wall_locs += component.objects
            _wall_locs = [_wall_locs[i] for i in sorted(np.unique(_wall_locs, return_index=True)[1])]
        else:
            _wall_locs = self._wall_locs

        all_patches = []
        for i_wall, wall in enumerate(_wall_locs):
            n_patch = self._model._get_int(wall + '.n_patch')
            for i_patch in range(n_patch):
                patch_name = self._model._get_str(wall + '.subcomponents:' +
                                                  str(i_patch))
                all_patches.append(wall+'.'+patch_name)
        return all_patches

# TODO: Remove Patch2022
class Patch2022(Component):
    """
    Patch2022 is based on Patch in Walmsley 2015.

    Parameters
    ==========
    Am_ref [:math:`m^2`]: float
        Reference wall area at :math:`l_{s} = l_{s,ref}`.
    V_wall [:math:`m^3`]: float
        Wall volume
    v_max [:math:`\\mu m/s`]: float
        Maximum shortening velocity
    l_se0 [:math:`\\mu m`]: float
        lgth of the series elastic element, i.e. :math:`l_{s} -l_{si}` for
        which stress is zero.
    l_s0 [:math:`\\mu m`]: float
        Reference sarcomere lgth for which at
        :math:`A_m (l_{s,ref}) = A_{m,ref}`.
    dl_s_pas [:math:`\\mu m`]: float
        Nonlinear exponent of Titin stress
    Sf_pas [Pa]: float
        Linear ECM stress coefficient
    fac_Sf_tit [-]: float
        Contribution factor of titen stress multiplied with Sf_act
    k1 [-]: float
        Nonlinear exponent ECM stress component
    tr [s]: float
        Contraction time constant
    td [s]: float
        Relaxation time constant
    time_act [-]: float
        Relative contraction duration
    Sf_act [Pa]: float
        Linear active stress component
    dt [s]: float
        Activation delay relative to intrinsic activation
    C_rest [-]: float
        Rest contractility
    l_si0 [:math:`\\mu m`]: float
        Reference lgth for zero-active-stress
    LDAD [s]: float
        strain dependend activation duration
    ADO [s]: float
        activation duration offset
    LDCC [-]: float
        stretch dependend contractility coefficient
    Sf_pasMaxT: float
        Maximum ecm stress (adaptation sens variable)
    Sf_pasActT: float
        Active weighted passive stress (adaptation sens variable)
    FacSf_actT: float
        Active stress (adaptation sens variable)
    LsPasActT: float
        Weighted sarcomere lgth average (adaptation sens variable)
    adapt_gamma: bool
        Adaptation constant

    Signals
    =======
    Signals are arrays. Each point in the array represents a point in time with
    step-size controlled by the solver.

    l_s [:math:`\\mu m`]: array
        Sarcomere lgth
    l_si [:math:`\\mu m`]: array
        State variable: Intrinsic sarcomere lgth
    LsiDot [:math:`\\mu m/s`]: array
        State variable: Intrinsic sarcomere lgth time-derivative
    C [-]: array
        State variable: contraction curve
    C_dot [1/s]: array
        State variable: contraction time-derivative
    Am [m:sup:`2`]: array
        Patch mid-wall area
    Am0 [m:sup:`2`]: array
        Patch mid-wall zero-stress area
    Ef [-]: array
        Natural strain
    T [Nm]: array
        Mid-wall tension
    dA_dT [m / N]: array
        Area-tension derivative
    Sf [Pa]: array
        Total fibre stress at mid-wall
    Sf_pasT [Pa]: array
        Total passive stress at mid-wall
    SfEcm [Pa]: array
        Total ECM stress at mid-wall
    dSf_dEf [Pa]: array
        Total stiffness coefficient
    dSf_pas_dEf [Pa]: array
        Total passive stiffness coefficient
    SfEcmMax: array
        Adaptation: Maximum ECM stress
    Sf_actMax: array
        Adaptation: maximum active stress
    Sf_pasAct: array
        Adaptation: active-weighted passive stress
    LsPasAct: array
        Adaptation: active-weigthed sarcomere lgth

    """

    parameters = [
        'Am_ref',
        'V_wall',
        'v_max',
        'l_se0',
        'l_s0',
        'l_s_ref',
        'dl_s_pas',
        'Sf_pas',
        'tr',
        'td',
        'time_act',
        'Sf_act',
        'fac_Sf_tit',
        'k1',
        'dt',
        'C_rest',
        'l_si0',
        'LDAD',
        'ADO',
        'LDCC',
        'SfPasMaxT',
        'SfPasActT',
        'FacSfActT',
        'LsPasActT',
        'adapt_gamma',
        ]

    signals = [
        'l_s',
        'l_si',
        'l_si_dot',
        'C',
        'C_dot',
        'Cm',
        'Am',
        'Am0',
        'Ef',
        'T',
        'dA_dT',
        'Sf',
        'Sf_pas_total',
        'Sf_ecm',
        'dSf_dEf',
        'dSf_pas_dEf',
        'SfEcmMax',
        'SfActMax',
        'SfPasAct',
        'LsPasAct'
        ]

    def __init__(self, model, objects=None, wall_locs=None):
        """
        Patch2022 is based on Patch in Walmsley 2015.

        Number of patches and their names may vary and are automatically
        detected from the model object.

        Parameters
        ----------
        model: circadapt.Circadapt
            Model object.
        objects: list, optional
            List of objects in c++ this object refers to. If not given,
            the list is build based on wall_locs.
        wall_locs: list, optional
            List of wall locations in c++. This list is used to generate the
            objects.

        """
        self._model = model
        self._wall_locs = wall_locs
        if objects is None:
            objects = self.get_all_patches()
        super().__init__(model, objects)

    def build(self):
        """
        (re)build patch locations based on wall locations.

        There is no compatibility with different types of patches used in the
        model. If you use different type of patches, please use the direct way
        of interacting with the c++ object, i.e. set() and get().
        """
        self.objects = self.get_all_patches()
        super().build()

    def get_all_patches(self):
        """Get all patches of the walls included in this pointer object."""

        # get all wall objects from all possible walls
        if self._wall_locs is None:
            _wall_locs = []
            for component in self._model._components.values():
                if isinstance(component, (Wall2022, LoadExperiment)):
                    _wall_locs += component.objects
        else:
            _wall_locs = self._wall_locs

        all_patches = []
        for i_wall, wall in enumerate(_wall_locs):
            n_patch = self._model._get_int(wall + '.n_patch')
            for i_patch in range(n_patch):
                patch_name = self._model._get_str(wall + '.subcomponents:' +
                                                  str(i_patch))
                all_patches.append(wall+'.'+patch_name)
        return all_patches
