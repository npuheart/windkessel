def strip_base(base):
    if base is None:
        base = ''
    elif len(base) > 0 and base[-1] != '.':
        base = base + '.'
    return base


def build_artven(self, base=None, **kwargs):
    options = {'build': 'SystemicCirculation'}
    options.update(kwargs)

    base = strip_base(base)

    if options['build'] == 'SystemicCirculation':
        # Create and link Components
        self.add_component('ArtVen', 'CiSy', base[:-1]+'')
        self.add_component('Tube0D', 'SyArt', base[:-1]+'')
        self.add_component('Tube0D', 'SyVen', base[:-1]+'')

        self.set_component(base+'SyArt.adaptation_cavity', base[:-1]+'CiSy')
        self.set_component(base+'SyVen.adaptation_cavity', base[:-1]+'CiSy')

        # Link objects
        self.set_component('CiSy.prox', 'SyArt')
        self.set_component('CiSy.dist', 'SyVen')

        # Parameterize
        self.set('Model.CiSy.k', 1)
        self.set('Model.CiSy.p0', 6550)
        self.set('Model.CiSy.q0', 4.5e-5)

        self.set('Model.SyArt.V', 2e-4)
        self.set('Model.SyArt.A0', 0.0004970825734583307)
        self.set('Model.SyArt.A_wall', 0.00011391746501259797)
        self.set('Model.SyArt.k', 5 / 3)
        self.set('Model.SyArt.l', 0.4)
        self.set('Model.SyArt.p0', 12166.38)
        self.set('Model.SyArt.scaleV', 1e-5)

        self.set('Model.SyVen.V', 4e-4)
        self.set('Model.SyVen.A0', 0.0004992166387264159)
        self.set('Model.SyVen.A_wall', 4.59301961400394e-05)
        self.set('Model.SyVen.k', 7 / 3)
        self.set('Model.SyVen.l', 0.4)
        self.set('Model.SyVen.p0', 140.9967809576559)
        self.set('Model.SyVen.scaleV', 1e-5)

    elif options['build'] == 'PulmonaryCirculation':
        # Create and link Components
        self.add_component('ArtVen', 'CiPu', base[:-1]+'')
        self.add_component('Tube0D', 'PuArt', base[:-1]+'')
        self.add_component('Tube0D', 'PuVen', base[:-1]+'')

        self.set_component(base+'PuArt.adaptation_cavity', base+'CiPu')
        self.set_component(base+'PuVen.adaptation_cavity', base+'CiPu')

        # Link objects
        self.set_component(base + 'CiPu.prox', base+'PuArt')
        self.set_component(base + 'CiPu.dist', base+'PuVen')

        # Parameterize
        self.set(base + 'CiPu.k', 2)
        self.set(base + 'CiPu.p0', 1500)
        self.set(base + 'CiPu.q0', 4.5e-5)

        self.set(base + 'PuArt.V', 1e-4)
        self.set(base + 'PuArt.A0', 0.0004683231348739835)
        self.set(base + 'PuArt.A_wall', 8.830762085649456e-05)
        self.set(base + 'PuArt.k', 5 / 3)
        self.set(base + 'PuArt.l', 0.2)
        self.set(base + 'PuArt.p0', 2459.4806733964256)
        self.set(base + 'PuArt.scaleV', 1e-5)

        self.set(base + 'PuVen.V', 2e-4)
        self.set(base + 'PuVen.A0', 0.0005138610352478564)
        self.set(base + 'PuVen.A_wall', 4.837402180262195e-05)
        self.set(base + 'PuVen.k', 7 / 3)
        self.set(base + 'PuVen.l', 0.2)
        self.set(base + 'PuVen.p0', 505.49687688319267)
        self.set(base + 'PuVen.scaleV', 1e-5)
