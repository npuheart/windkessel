def strip_base(base):
    if base is None:
        base = ''
    elif len(base) > 0 and base[-1] != '.':
        base = base + '.'
    return base


def build_heart(self, base=None, options=None):
    _options = {
        'chamber_type': None,
        'triseg_type': None,
        'patch_type': None,
        'valve_type': None,
        'PuArt': 'PuArt',
        'SyVen': 'SyVen',
        'PuVen': 'PuVen',
        'SyArt': 'SyArt',
        }
    if options is not None:
        _options.update(options)
    options = _options

    # defaults
    if options['patch_type'] is None:
        options['patch_type'] = 'Patch2022'
    if options['valve_type'] is None:
        options['valve_type'] = 'Valve2022'

    # Todo: remove Chamber2022
    if options['chamber_type'] is None and options['patch_type']  == 'Patch2022':
        options['chamber_type'] = 'Chamber2022'
    elif options['chamber_type'] is None:
        options['chamber_type'] = 'Chamber'

    # Todo: remove TriSeg
    if options['triseg_type'] is None and options['patch_type']  == 'Patch2022':
        options['triseg_type'] = 'TriSeg2022'
    elif options['triseg_type'] is None:
        options['triseg_type'] = 'TriSeg'


    base = strip_base(base)

    # Create components
    self.add_component('Bag', 'Peri', base[:-1])

    # add atria
    self.add_component(options['chamber_type'], 'La', base+'Peri')
    self.add_component(options['patch_type'], 'pLa0', base+'Peri.La.wLa')
    self.add_component(options['chamber_type'], 'Ra', base+'Peri')
    self.add_component(options['patch_type'], 'pRa0', base+'Peri.Ra.wRa')

    # add ventricles
    self.add_component(options['triseg_type'], 'TriSeg', base+'Peri')
    self.add_component(options['patch_type'], 'pLv0', base+'Peri.TriSeg.wLv')
    self.add_component(options['patch_type'], 'pSv0', base+'Peri.TriSeg.wSv')
    self.add_component(options['patch_type'], 'pRv0', base+'Peri.TriSeg.wRv')

    # add valves
    self.add_component(options['valve_type'], 'SyVenRa', base+'Peri')
    self.add_component(options['valve_type'], 'RaRv', base+'Peri')
    self.add_component(options['valve_type'], 'RvPuArt', base+'Peri')
    self.add_component(options['valve_type'], 'PuVenLa', base+'Peri')
    self.add_component(options['valve_type'], 'LaLv', base+'Peri')
    self.add_component(options['valve_type'], 'LvSyArt', base+'Peri')

    # Link components
    self.set_component(base + 'Peri.SyVenRa.prox', options['SyVen'])
    self.set_component(base + 'Peri.SyVenRa.dist', base + 'Peri.Ra')
    self.set_component(base + 'Peri.RaRv.prox', base + 'Peri.Ra')
    self.set_component(base + 'Peri.RaRv.dist', base + 'Peri.TriSeg.cRv')
    self.set_component(base + 'Peri.RvPuArt.prox', base + 'Peri.TriSeg.cRv')
    self.set_component(base + 'Peri.RvPuArt.dist', options['PuArt'])

    self.set_component(base + 'Peri.PuVenLa.prox', options['PuVen'])
    self.set_component(base + 'Peri.PuVenLa.dist', base + 'Peri.La')
    self.set_component(base + 'Peri.LaLv.prox', base + 'Peri.La')
    self.set_component(base + 'Peri.LaLv.dist', base + 'Peri.TriSeg.cLv')
    self.set_component(base + 'Peri.LvSyArt.prox', base + 'Peri.TriSeg.cLv')
    self.set_component(base + 'Peri.LvSyArt.dist', options['SyArt'])

    self.set_component(base + 'Peri.SyVenRa.adaptation_cavity', options['SyArt'])
    self.set_component(base + 'Peri.RaRv.adaptation_cavity', options['PuArt'])
    self.set_component(base + 'Peri.RvPuArt.adaptation_cavity', options['PuArt'])
    self.set_component(base + 'Peri.PuVenLa.adaptation_cavity', options['PuVen'])
    self.set_component(base + 'Peri.LaLv.adaptation_cavity', options['SyArt'])
    self.set_component(base + 'Peri.LvSyArt.adaptation_cavity', options['SyArt'])

    # Parameterize components
    self.set('Model.'+base+'Peri.TriSeg.V', 44e-6)
    self.set('Model.'+base+'Peri.TriSeg.Y', 34.6e-3)

    self.set('Model.'+base+'Peri.TriSeg.cLv.V',  100e-6)
    self.set('Model.'+base+'Peri.TriSeg.cRv.V',  100e-6)
    self.set('Model.'+base+'Peri.La.V',  50e-6)
    self.set('Model.'+base+'Peri.Ra.V',  50e-6)

    set_parameters_walmsley2015_heart(self, base)

def set_parameters_walmsley2015_heart(self, base):
    # all wall parameters
    locs = ['Peri.TriSeg.wLv.pLv0',
            'Peri.TriSeg.wSv.pSv0',
            'Peri.TriSeg.wRv.pRv0',
            'Peri.La.wLa.pLa0',
            'Peri.Ra.wRa.pRa0',
            ]
    for loc in locs:
        self.set('Model.'+base+loc+'.l_se0', 0.04)
        self.set('Model.'+base+loc+'.l_s0', 2.0)
        self.set('Model.'+base+loc+'.l_s0', 1.8)
        self.set('Model.'+base+loc+'.dl_s_pas', 0.6)
        self.set('Model.'+base+loc+'.k1', 10)
        self.set('Model.'+base+loc+'.dt', 0)
        self.set('Model.'+base+loc+'.C_rest', 0)
        self.set('Model.'+base+loc+'.l_si0', 1.51)
        self.set('Model.'+base+loc+'.LDAD', 1.057)
        self.set('Model.'+base+loc+'.ADO', 0.65)
        self.set('Model.'+base+loc+'.LDCC', 4)

    # wall specific
    self.set('Model.'+base+'Peri.TriSeg.wLv.pLv0.Am_ref', 0.009805314057621018)
    self.set('Model.'+base+'Peri.TriSeg.wLv.pLv0.V_wall', 9.60080108859341e-05)
    self.set('Model.'+base+'Peri.TriSeg.wLv.pLv0.v_max', 7.0)
    self.set('Model.'+base+'Peri.TriSeg.wLv.pLv0.Sf_pas', 500)
    self.set('Model.'+base+'Peri.TriSeg.wLv.pLv0.tr', 0.25)
    self.set('Model.'+base+'Peri.TriSeg.wLv.pLv0.td', 0.25)
    self.set('Model.'+base+'Peri.TriSeg.wLv.pLv0.Sf_act', 100000)

    self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.Am_ref', 0.004884229725474014)
    # self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.Am_ref', 0.0045)
    self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.V_wall', 3.23553932981624e-05)
    # self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.V_wall', 4e-05)
    self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.v_max', 7.0)
    self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.Sf_pas', 500)
    self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.tr', 0.25)
    self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.td', 0.25)
    self.set('Model.'+base+'Peri.TriSeg.wSv.pSv0.Sf_act', 100000)

    self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.Am_ref', 0.012970820071535782)
    # self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.Am_ref', 0.01)
    self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.V_wall', 6.29708653593736e-05)
    # self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.V_wall', 8e-05)
    self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.v_max', 7.0)
    self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.Sf_pas', 500)
    self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.tr', 0.25)
    self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.td', 0.25)
    self.set('Model.'+base+'Peri.TriSeg.wRv.pRv0.Sf_act', 100000)

    self.set('Model.'+base+'Peri.La.wLa.pLa0.Am_ref', 0.006921646911242356)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.Am_ref', 0.007)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.V_wall', 1.5582632867621123e-05)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.V_wall', 1.6e-05)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.v_max', 14.0)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.Sf_pas', 4000)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.tr', 0.4)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.td', 0.4)
    self.set('Model.'+base+'Peri.La.wLa.pLa0.Sf_act', 84000)

    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.Am_ref', 0.0059862195992063825)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.Am_ref', 0.008)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.V_wall', 6.389451836068464e-05)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.V_wall', 1e-05)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.v_max', 14.0)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.Sf_pas', 4000)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.tr', 0.4)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.td', 0.4)
    self.set('Model.'+base+'Peri.Ra.wRa.pRa0.Sf_act', 84000)

def build_timings(self, base=None, options=None):
    _options = {'build': 'Walmsley2015',
                }
    if options is not None:
        _options.update(options)
    options = _options

    base = strip_base(base)

    if options['build'] == 'Walmsley2015':
        self.add_component('Timings', 'Timings', base[:-1]+'')

        self.set_component(base+'Timings.wLa', base + 'Peri.La.wLa')
        self.set_component(base+'Timings.wRa', base + 'Peri.Ra.wRa')
        self.set_component(base+'Timings.wLv', base + 'Peri.TriSeg.wLv')
        self.set_component(base+'Timings.wSv', base + 'Peri.TriSeg.wSv')
        self.set_component(base+'Timings.wRv', base + 'Peri.TriSeg.wRv')

def build_pfc(self, base=None, options=None):
    _options = {'build': 'Walmsley2015',
                }
    if options is not None:
        _options.update(options)
    options = _options

    base = strip_base(base)
    if options['build'] == 'Walmsley2015':
        self.add_component('PressureFlowControl', 'PFC', base[:-1]+'')

        self.set_component('PFC.node_pressure', 'SyArt')
        self.set_component('PFC.connector_return', base+'Peri.SyVenRa')
        self.set_component('PFC.artven_resistance', 'CiSy')
        self.set_component('PFC.valve_flow_vec', base+'Peri.SyVenRa')
        self.set_component('PFC.valve_flow_vec', base+'Peri.RaRv')
        self.set_component('PFC.valve_flow_vec', base+'Peri.RvPuArt')
        self.set_component('PFC.valve_flow_vec', base+'Peri.PuVenLa')
        self.set_component('PFC.valve_flow_vec', base+'Peri.LaLv')
        self.set_component('PFC.valve_flow_vec', base+'Peri.LvSyArt')
        self.set_component('PFC.link_fac_pfc', 'CiSy')
        self.set_component('PFC.link_fac_pfc', 'CiPu')
