def add_smart_component(self, smart_component, base=None, **kwargs):
    if smart_component == 'Heart':
        return self.build_heart(base, kwargs)
    if smart_component == 'ArtVen':
        return self.build_artven(base, **kwargs)
    if smart_component == 'Timings':
        return self.build_timings(base, kwargs)
    if smart_component == 'PressureFlowControl':
        return self.build_pfc(base, kwargs)
    raise ValueError('smart_component unknown')
