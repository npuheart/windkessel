"""Wall objects."""
from circadapt.components import Component


def rebuild_patch2022(model):
    """Rebuilds patches of the model, e.g. for when n_patch changed."""
    # import here to prevent circular import
    from circadapt.components.patch import Patch2022
    for component in model._components.values():
        if isinstance(component, Patch2022):
            component.build()


def rebuild_patch(model):
    """Rebuilds patches of the model, e.g. for when n_patch changed."""
    # import here to prevent circular import
    from circadapt.components.patch import Patch
    for component in model._components.values():
        if isinstance(component, Patch):
            component.build()


class Wall(Component):
    """
    Wall object.

    Parameters
    ==========
    Am_dead: float
        Non-conctractile wall area.
    n_patch: int
        Number of patches in the wall. On increase, the last patch will be
        copied. Wall volume and area are distributed equally over the patches.
        On decrease, the last patches in the list will be removed.

    Signals
    =======
    Signals are arrays. Each point in the array represents a point in time with
    step-size controlled by the solver.

    Am [m :sup:`2`]: array
        Wall area
    Am0 [m :sup:`2`]: array
        Linearized stress-free wall area
    Cm [1/m]: array
        Wall curvature
    dA_dT [m/N]: array
        Stress-tension derivative
    p_trans [Pa]: array
        Transmural pressure
    T [Nm]: array
        Tension
    Vm [m :sup:`3`]: array
        Mid-wall volume
    V_wall [m :sup:`3`]: double
        Wall volume
    """

    parameters = [
        'Am_dead',
        'n_patch',
    ]
    parameter_on_set = {
        # default patch, overwrite when other patches are used
        'n_patch': rebuild_patch
    }

    signals = [
        'A',
        'Am',
        'Am0',
        'Cm',
        'dA_dT',
        'p_trans',
        'T',
        'Vm',
        'V_wall',
    ]


class Wall2022(Component):
    """
    Wall2022 object.

    Parameters
    ==========
    Am_dead: float
        Non-conctractile wall area.
    n_patch: int
        Number of patches in the wall. On increase, the last patch will be
        copied. Wall volume and area are distributed equally over the patches.
        On decrease, the last patches in the list will be removed.

    Signals
    =======
    Signals are arrays. Each point in the array represents a point in time with
    step-size controlled by the solver.

    Am [m :sup:`2`]: array
        Wall area
    Am0 [m :sup:`2`]: array
        Linearized stress-free wall area
    Cm [1/m]: array
        Wall curvature
    dA_dT [m/N]: array
        Stress-tension derivative
    p_trans [Pa]: array
        Transmural pressure
    T [Nm]: array
        Tension
    Vm [m :sup:`3`]: array
        Mid-wall volume
    V_wall [m :sup:`3`]: double
        Wall volume
    """

    parameters = [
        'Am_dead',
        'n_patch',
    ]
    parameter_on_set = {
        # default patch2022, overwrite when other patches are used
        'n_patch': rebuild_patch2022
    }

    signals = [
        'A',
        'Am',
        'Am0',
        'Cm',
        'dA_dT',
        'p_trans',
        'T',
        'Vm',
        'V_wall',
    ]


class LoadExperiment(Wall):
    """
    PreAfterloadExperiment object.

    Parameters
    ==========
    Am_dead: float
        Non-conctractile wall area.
    Am_ref_afterload: float
        Wall area at :math:`T_{m} = Tafterload`.
    n_patch: int
        Number of patches. On change, the last patch is splitted or last
        patches are removed.
    n_iter: int
        Number of iterations to calculate mechanical stability.
    T_afterload: float
        Maximum wall tension. When tension is reached, wall area shortens.

    Signals
    =======
    Signals are arrays. Each point in the array represents a point in time with
    step-size controlled by the solver.

    Am: array
        Wall area
    Am0: array
        Linearized stress-free wall area
    Cm: array
        Wall curvature
    dA_dT: array
        Stress-tension derivative
    T: array
        Tension
    p_trans: array
        Transmural pressure
    """
    parameters = [
        'Am_dead',
        'Am_ref_afterload',
        'n_patch',
        'n_iter',
        'T_afterload',
    ]
    parameter_on_set = {
        'n_patch': rebuild_patch,
    }
    signals = [
        'A',
        'Am',
        'Am0',
        'Cm',
        'dA_dT',
        'p_trans',
        'T',
        'Vm',
        'V_wall',
    ]
