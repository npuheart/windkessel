"""Connector objects."""
from circadapt.components import Component


class Connector(Component):
    """Connector objects."""

    parameters = [
        'prox',
        'dist',
        ]

    signals = [
        'q',
        ]

    def add(self, name, prox, dist):
        super().add(name)
        self._model.set_component(name+'.prox', prox)
        self._model.set_component(name+'.dist', dist)


class ArtVen(Connector):
    """
    ArtVen connects two nodes with a passive, flow-dependent resistance.

    Parameters
    ==========
    k [-]: double
        Exponent in pressure-flow relationship
    p0 [Pa]: double
        Reference pressure at q=q0
    q0 [m :sup:`3`/s]: double
        Reference flow at p=p0

    Signals
    ==========
    q [m :sup:`3`/s]: float
        Flow over ArtVen
    """

    parameters = [
        'p0',
        'q0',
        'k',
        'prox',
        'dist',
        ]

    signals = [
        'q',
        ]


class ArtVen2022(Connector):
    """ArtVen2022 object."""

    parameters = [
        'p0',
        'q0AV',
        'kAV',
        'prox',
        'dist',
        ]

    signals = [
        'q',
        ]


class Diode(Connector):
    """
    Ideal diode describing flow between nodes at positive pressure gradient.


    Parameters
    ==========
    R: double
        Resistance

    Signals
    ==========
    q: float
        Flow through the valve
    """
    parameters = [
        'R',
        'prox',
        'dist',
        ]

    signals = [
        'q',
        ]


class Resistance(Connector):
    """
    Simple Resistance describing flow between nodes.


    Parameters
    ==========
    R: double
        Resistance

    Signals
    ==========
    q: float
        Flow through the valve
    """

    parameters = [
        'R',
        'prox',
        'dist',
        ]

    signals = [
        'q',
        ]


class Valve2022(Connector):
    r"""
    Module to simulate valvular flow.

    This model simulates flow :math:`q` based on the pressure gradient between
    the proximal and distal node :math:`\Delta p` by solving the ordinary
    differential equation:

    .. math::
        \frac{dq}{dt} = \frac{A_{eff}}{l_{eff}}  \Bigg[\frac{q\cdot|q|}{2}
        (\frac{1}{A_{prox}^2}-\frac{1}{A_{eff}^2})+\frac{\Delta p}{\rho}\Bigg]


    Parameters
    ----------
    adaptation_Aopen_fac [-]: double
        Factor used in adaptation to determine Aopen based on vessel flow.
    A_open [m\ :sup:`2`]: float
        Opening area
    A_leak [m\ :sup:`2`]: float
        Leaking valve area
    l [m]: float
        Length of valve
    rho_b [kg/m\ :sup:`3`]: float
        Blood density
    papillary_muscles [-]: bool
        If true, papilary muscle implementation is activated
    soft_closure [-]: bool
        If true, a soft closure is activated

    Signals
    -------
    q [m\ :sup:`3`/s]: float
        Flow through the valve
    dq_dt [m\ :sup:`3`/s\ :sup:`2`]: float
        Time derivative of the flow q

    """

    parameters = [
        'adaptation_A_open_fac',
        'A_open',
        'A_leak',
        'l',
        'L_fac_prox',
        'L_fac_dist',
        'L_fac_valve',
        'rho_b',
        'papillary_muscles',
        'papillary_muscles_slope',
        'papillary_muscles_min',
        'papillary_muscles_A_open_fac',
        'soft_closure',
        'fraction_A_open_Aext',
        'prox',
        'dist',
        ]

    signals = [
        'q',
        'dq_dt',
        'L',
        'A',
        'Dp',
        'DpB',
        'diast',
        ]

    
class Valve(Connector):
    r"""
    Module to simulate valvular flow.

    This model simulates flow :math:`q` based on the pressure gradient between
    the proximal and distal node :math:`\Delta p` by solving the ordinary
    differential equation:

    .. math::
        \frac{dq}{dt} = \frac{A_{eff}}{l_{eff}}  \Bigg[\frac{q\cdot|q|}{2}
        (\frac{1}{A_{prox}^2}-\frac{1}{A_{eff}^2})+\frac{\Delta p}{\rho}\Bigg]


    Parameters
    ----------
    adaptation_Aopen_fac [-]: double
        Factor used in adaptation to determine Aopen based on vessel flow.
    A_open [m\ :sup:`2`]: float
        Opening area
    A_leak [m\ :sup:`2`]: float
        Leaking valve area
    l [m]: float
        Length of valve
    rho_b [kg/m\ :sup:`3`]: float
        Blood density
    papillary_muscles [-]: bool
        If true, papilary muscle implementation is activated
    soft_closure [-]: bool
        If true, a soft closure is activated

    Signals
    -------
    q [m\ :sup:`3`/s]: float
        Flow through the valve
    dq_dt [m\ :sup:`3`/s\ :sup:`2`]: float
        Time derivative of the flow q

    """

    parameters = [
        'adaptation_A_open_fac',
        'A_open',
        'A_leak',
        'l',
        'L_fac_prox',
        'L_fac_dist',
        'L_fac_valve',
        'rho_b',
        'papillary_muscles',
        'papillary_muscles_slope',
        'papillary_muscles_min',
        'papillary_muscles_A_open_fac',
        'soft_closure',
        'fraction_A_open_Aext',
        'prox',
        'dist',
        ]

    signals = [
        'q',
        'dq_dt',
        'L',
        'A',
        'Dp',
        'DpB',
        'diast',
        ]


class Valve2024(Valve2022):
    pass
