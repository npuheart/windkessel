"""Cavity objects."""
from circadapt.components import Component


class Cavity(Component):
    """
    Basic Cavity object.

    Signals
    ----------
    A [m :sup:`2`]: array,
        Cavity Area
    p [Pa]: array,
        Pressure in node
    p_trans [Pa]: array,
        Transmural pressure
    q [m :sup:`3`]: array
        Flow in node
    V [m :sup:`3`]: array,
        Volume in Cavity
    dV_dt [m :sup:`3`]: array,
        Volume time derivative
    """

    parameters = [
        ]

    signals = [
        'A',
        'p',
        'p_trans',
        'q',
        'V',
        'dV_dt'
        ]


class Bag(Component):
    """
    Bag is designed to simulate the pericardium

    Parameters
    ----------
    k [-]: float
        Nonlinear exponent
    p_ref [Pa]: float
        Reference pressure for which hold p(V_ref) = p_ref
    V_ref [m :sup:`3`]: float
        Reference volume for which hold p(V_ref) = p_ref

    Signals
    -------
    V [m :sup:`3`]: array
        Volume enclosed by the Bag
    p [Pa]: array
        Pressure inside the Bag
    """

    parameters = [
        'k',
        'p_ref',
        'V_ref',
        ]

    signals = [
        'V',
        'p',
        ]


class Capacitor(Cavity):
    """
    Bag is designed to simulate the pericardium

    Parameters
    ----------
    Vo: double
        Reference volume for which hold p=0
    C: double
        Linear capacitance of cavity

    Signals
    -------
    V: array
        Volume enclosed by the Bag
    p: array
        Pressure inside the Bag Cavity
    """

    parameters = [
        'V0',
        'C',
        ]

    signals = [
        'V',
        ]


class Tube0D(Component):
    """
    Tube0D is designed to simulate pressure-volume relations of vessels.

    Parameters
    ----------
    l [m]: double
        Length of the tube
    A_wall [m :sup:`2`]: double
        Cross-sectional area of the wall
    k [-]: double
        Stiffness coefficient of the wall
    p0 [Pa]: double
        Pressure at A=A0
    A0 [m :sup:`2`]: double
        Cross-sectional cavity area for p=p0
    target_wall_stress: double
        Adaptation target for wall stress
    target_mean_flow: double
        Adaptation target for mean flow

    Signals
    -------
    V [m :sup:`3`]: array
        Volume in the Cavity
    p [Pa]: array
        Pressure in the Node
    """

    parameters = [
        'l',
        'A_wall',
        'k',
        'p0',
        'A0',
        'target_wall_stress',
        'target_mean_flow',
        ]

    signals = [
        'V',
        'p',
        ]


class Chamber(Component):
    """
    Chamber is a thick-walled sphere with a :ref:`Wall` describing the pressure
    :math:`p=f(A_m, C_m)`.

    Parameters
    ----------
    buckling: bool
        Buckling function. If True, wall tension cannot be below zero.

    Signals
    -------
    V [m :sup:`3`]: array
        Volume of the Cavity
    p [Pa]: array
        Pressure in the Node
    """

    parameters = [
        'buckling',
        ]

    signals = [
        'V',
        'p',
        'V',
        'dV_dt',
        'A',
        'Y',
        'q',
        ]

    def add_object(self, loc):
        super().add_object(loc)

        # library automatically creates wall for Chamber
        wall_loc = loc + '.' + self._model._get_str(loc+'.subcomponents:0')
        self._model._check_component_in_export_list_and_add_object(
            self._model._get_str(wall_loc+'.type'),
            wall_loc,
            )


class Chamber2022(Component):
    """
    Chamber2022 object.

    Parameters
    ----------
    buckling: bool
        Buckling function. If True, wall tension cannot be below zero.

    Signals
    -------
    V [m :sup:`3`]: array
        Volume of the Cavity
    p [Pa]: array
        Pressure in the Node
    """

    parameters = [
        'buckling',
        ]

    signals = [
        'V',
        'p',
        'V',
        'dV_dt',
        'A',
        'Y',
        'q',
        ]

    def add_object(self, loc):
        super().add_object(loc)

        # library automatically creates wall for Chamber
        wall_loc = loc + '.' + self._model._get_str(loc+'.subcomponents:0')
        self._model._check_component_in_export_list_and_add_object(
            self._model._get_str(wall_loc+'.type'),
            wall_loc,
            )

# TODO: remove 2022
class TriSeg2022(Component):
    """
    TriSeg2022 is designed to represent ventricles including interaction.


    Parameters
    ----------
    tau: float [-]
        Constant to limit change in estimation of dV and dY

    Signals
    -------
    V [m :sup:`3`]: array
        Volume of truncated septal wall
    V0 [m :sup:`3`]: array
        Volume of truncated septal wall before finding mechanical equilibrium
    dV_dt [m :sup:`3`/s]: array
        Time-derivative of V, used to find the estimation V0
    Y [m]: array
        Distance of wall-junction to center
    Y0 [m]: array
        Distance of wall-junction to center before finding mechanical
        equilibrium
    YDot [m/s]: array
        Time-derivative of Y, used to find the estimation Y0
    """

    parameters = [
        'tau',
        'ratio_septal_LV_Am',
        ]

    signals = [
        'V',
        'Y',
        'V0',
        'Y0',
        'dV_dt',
        'YDot',
        'n_loop',
        'Fp',
        'Fv',
        ]

    def add_object(self, loc):
        """Link a c++ object to this object."""
        super().add_object(loc)
        self._model._check_component_in_export_list_and_add_object('Cavity',
                                                                   loc+'.cLv')
        self._model._check_component_in_export_list_and_add_object('Cavity',
                                                                   loc+'.cRv')

        self._model._check_component_in_export_list_and_add_object('Wall2022',
                                                                   loc+'.wLv')
        self._model._check_component_in_export_list_and_add_object('Wall2022',
                                                                   loc+'.wSv')
        self._model._check_component_in_export_list_and_add_object('Wall2022',
                                                                   loc+'.wRv')



class TriSeg(Component):
    """
    TriSeg is designed to represent ventricles including interaction.


    Parameters
    ----------
    tau: float [-]
        Constant to limit change in estimation of dV and dY

    Signals
    -------
    V [m :sup:`3`]: array
        Volume of truncated septal wall
    V0 [m :sup:`3`]: array
        Volume of truncated septal wall before finding mechanical equilibrium
    dV_dt [m :sup:`3`/s]: array
        Time-derivative of V, used to find the estimation V0
    Y [m]: array
        Distance of wall-junction to center
    Y0 [m]: array
        Distance of wall-junction to center before finding mechanical
        equilibrium
    YDot [m/s]: array
        Time-derivative of Y, used to find the estimation Y0
    """

    parameters = [
        'tau',
        'ratio_septal_LV_Am',
        'max_number_of_iterations',
        'thresh_F',
        'thresh_dV',
        'thresh_dY',
        ]

    signals = [
        'V',
        'Y',
        'V0',
        'Y0',
        'dV_dt',
        'YDot',
        'n_loop',
        'Fp',
        'Fv',
        ]

    def add_object(self, loc):
        """Link a c++ object to this object."""
        super().add_object(loc)
        self._model._check_component_in_export_list_and_add_object('Cavity',
                                                                   loc+'.cLv')
        self._model._check_component_in_export_list_and_add_object('Cavity',
                                                                   loc+'.cRv')

        self._model._check_component_in_export_list_and_add_object('Wall',
                                                                   loc+'.wLv')
        self._model._check_component_in_export_list_and_add_object('Wall',
                                                                   loc+'.wSv')
        self._model._check_component_in_export_list_and_add_object('Wall',
                                                                   loc+'.wRv')

