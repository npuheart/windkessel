"""Solver objects."""

import numpy as np
from circadapt.components import General


class Solver(General):
    """
    Component object with no locations.

    Parameters
    ==========
    dt [s]: float
        Numerical timestep used for calculation
    dt_export [s]: float
        Numerical timestep used for export data
    max_beats [-]: int
        Maximum number of beats allowed to run stable
    store_beats [-]: int
        Number of beats stored

    Signals
    =======
    t [s]: float
        Time starting at zero
    t_real [s]: float
        Time, real time of the solver. Starts at zero when model is created.
    stable_beats_needed [-]: int
        Number of beats runned to get to stable situation.
    """

    parameters = {
        'dt': 'Solver.dt',
        'dt_export': 'Solver.dt_export',
        'max_beats': 'Solver.max_beats',
        'store_beats': 'Solver.store_beats',
        }

    signals = {
        't': 'Solver.t',
        't_real': 'Solver.t',
        'stable_beats_needed': 'Solver.stable_beats_needed',
        }

    def __getitem__(self, arg: any) -> any:
        ret = super().__getitem__(arg)
        if arg == 't' and len(ret)>0:
            ret -= ret[0]
        return ret
