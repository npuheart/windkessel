import os

from circadapt.circadapt import CircAdapt


class Model(CircAdapt):
    def __init__(self,
                 solver=None,
                 path_to_circadapt: str = None,
                 model_state: dict = None,
                 ):
        # set assert test settings
        self.assert_test_settings = {}

        # now create model
        CircAdapt.__init__(
            self,
            solver,
            path_to_circadapt=path_to_circadapt,
            model_state=model_state,
            )

        # rerun get_model_reference for first-time use
        # If P_ref_model is not there, it will be created here
        _ = self.get_model_reference()

    def plot(self, fig=None):
        """Simple plot to illustrate the model state."""

    def plot_extended(self, fig=None):
        """Extended plot to illustrate the model state."""
        self.plot(fig)

    def assert_1_beat(self):
        """Test status after 1 beat, used in unit tests."""

    def get_unittest_targets(self):
        """Hardcoded results after initializing and running 1 beat."""
        return {}

    def get_unittest_results(self, model):
        """Real-time results after initializing and running 1 beat."""
        return {}

    def health_check(self):
        """Manually perform tests to check compatibility of model with version."""
        self.load_reference()
        self.run(1)
        targets = self.get_unittest_targets()
        results = self.get_unittest_results(self)

        for key, value in targets.items():
            number_of_decimals = len(str(value).split(".")[1])
            assert(round(value*10**number_of_decimals) ==
                   round(results[key]*10**number_of_decimals))

        n_test_targets = len(targets)
        print(f'All {n_test_targets} tests are passed.')

    def install(self):
        self.health_check()

        filename = self._get_reference_filename()
        folder = os.path.dirname(filename)

        if not os.path.isdir(folder):
            os.mkdir(folder)

        self.load_reference()
        self.save(filename)
