"""CircAdapt settings
Define setting parameters
"""

__version__ = '2412'
__author__ = 'Nick van Osta'
