"""
@package CircAdapt.

CircAdapt is a modelling framework of the cardiovascular system.
The framework is written in C++ and this package is a wrapper to use
CircAdapt in python. The default CircAdapt is empty. The other class
descriptions automatically build the corresponding model.
"""

import platform

# %% Default path
DEFAULT_PATH_TO_CIRCADAPT = "CircAdapt."
"""
Default path to CircAdapt.dll.

Do not change this unless you develop the c++ code.
By default, it points to the compiled dll file in the package.
"""

# Add extension to default path
if platform.system() == 'Windows':
    DEFAULT_PATH_TO_CIRCADAPT += 'dll'
elif platform.system() == 'Linux':
    DEFAULT_PATH_TO_CIRCADAPT += 'so'
elif platform.system() == 'Mac':
    DEFAULT_PATH_TO_CIRCADAPT += 'lib'


def get_default_path_to_circadapt():
    return DEFAULT_PATH_TO_CIRCADAPT


# %% define for documentation
class CircAdapt:
    pass

# %% import structures
from circadapt.error import ModelCrashed, TriggerNotFound, CorruptBuild
from .settings import __version__
from circadapt.circadapt import CircAdapt, load_plugin_components
from circadapt.model.vanosta2023 import VanOsta2023
from circadapt.model.vanosta2024 import VanOsta2024
