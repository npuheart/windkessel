"""Cavity objects."""
from circadapt.components import Component


class Node(Component):
    """Basic Cavity object."""

    parameters = [
        ]

    signals = [
        'A',
        'p',
        'q',
        ]

