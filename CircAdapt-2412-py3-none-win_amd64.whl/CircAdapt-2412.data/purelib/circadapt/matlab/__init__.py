# -*- coding: utf-8 -*-
import scipy.io as sio

######
# Functions needed for loadMat
######
def _check_keys(data):
    """
    checks if entries in dictionary are mat-objects. If yes
    todict is called to change them to nested dictionaries
    """
    for key in data:
        if isinstance(data[key], sio.matlab.mio5_params.mat_struct):
            data[key] = _todict(data[key])
    return data


def _todict(matobj):
    """
    A recursive function which constructs from matobjects nested dictionaries
    """
    data = {}
    for strg in matobj._fieldnames:
        elem = matobj.__dict__[strg]
        if isinstance(elem, sio.matlab.mio5_params.mat_struct):
            data[strg] = _todict(elem)
        else:
            data[strg] = elem
    return data
